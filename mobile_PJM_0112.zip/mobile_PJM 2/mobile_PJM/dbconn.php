<?
 $connect=mysqli_connect( "localhost", "dotji00", "codeblue12!","dotji00") or  
        die( "SQL server에 연결할 수 없습니다."); 

    mysqli_select_db($connect,"dotji00");

?>