<?
echo("
           <script>
             window.alert('시스템 준비중입니다.')
             history.go(-1)
           </script>
         ");
?>